# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 13:08:17 2018

@author: Mohit Sharma
"""
# What is a block of a code
age = 29
height = 180

if age > 30:
    print('My age is {} and my height is{}'.format(age, height))

# indendation defines the block.
"""
Blocks do not define scope in Python. Functions, objects, and 
modules do define scope in Python and you'll see examples of 
this later in this course.
"""

# Adding x in the above if statment and then printing it
# out of the block.
